// EmailSent.jsx

import React from 'react';

const EmailSent = () => {
    return (
      <div>
        An email has been sent to your email address. Please check your inbox.
      </div>
    );
  };
  
  export default EmailSent;
  